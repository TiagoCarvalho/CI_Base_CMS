<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?= $this->lang['title']; ?></title>
<script language="javascript" type="text/javascript">
var js = "<?=$this->data['js']?>";
var formname = "<?=$this->data['formname']?>";
var elementnames = "<?=$this->data['elementnames']?>";
var path = "<?=$this->data['path']?>";

function insertURL(url) {
	// Crop away query
	if ((pos = url.indexOf('?')) != -1)
		url = url.substring(0, url.indexOf('?'));

	// Handle custom js call
	if (window.opener && js != "") {
		eval("window.opener." + js + "(url);");
		top.close();
		return;
	}

	// Handle form item call
	if (window.opener && formname != "") {
		var elements = elementnames.split(',');

		for (var i=0; i<elements.length; i++) {
			var elm = window.opener.document.forms[formname].elements[elements[i]];
			if (elm && typeof elm != "undefined")
				elm.value = url;
		}
	}

	top.close();
}

function switchToImageManager(url_prefix, path) {
	var url = url_prefix + "/images.php?formname=" + formname + "&elementnames=" + elementnames + "&js=" + js + "&path=" + escape(path);
	top.location.href = url;
}
</script>
</head>

<? if ($this->data['showpreview']) { ?>
	<frameset rows="*" cols="*,300" framespacing="0" frameborder="no" border="0">
<? } else { ?>
	<frameset rows="*" cols="*,0" framespacing="0" frameborder="no" border="0">
<? } ?>
	<frame name="filelist" src="filelist.php?path=<?=$this->data['path']?>&rootpath=<?=$this->data['rootpath']?>#<?=$this->data['previewfilename']?>" frameborder="no" scrolling="no" noresize="noresize" marginwidth="0" marginheight="0" />
<? if ($this->data['showpreview']) { ?>
	<frame name="preview" src="preview.php?path=<?=$this->data['previewpath']?>" frameborder="no" scrolling="no" noresize="noresize" marginwidth="0" marginheight="0" />
</frameset>
<? } ?>

<noframes>
<body>
	This file browser requires a frameset.
</body>
</noframes>
</html>
