<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Blank</title>
<link href="themes/<?= $this->theme ?>/css/general.css" rel="stylesheet" type="text/css" />
</head>
<body>

</body>
</html>
