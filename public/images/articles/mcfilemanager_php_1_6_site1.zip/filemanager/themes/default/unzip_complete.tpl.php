<?= '<?xml version="1.0" encoding="iso-8859-1"?>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="sv" xml:lang="sv">
<head>
<title><?= $this->lang['title']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="themes/<?= $this->theme ?>/css/dialog.css" rel="stylesheet" type="text/css" media="all" />
<script language="javascript" type="text/javascript" src="themes/<?= $this->theme ?>/jscripts/general.js"></script>
<script language="javascript" type="text/javascript">

var demo = <?= $this->data['demo'] ?>;
var demoMsg = "<?= $this->data['demo_msg'] ?>";

function init() {
	if (window.opener)
		window.opener.execFileCommand("refresh");
<? if ($this->data['errorMsg']) { ?>
	alert("<?=$this->data['errorMsg']?>");
<? } ?>
}
</script>
<style type="text/css">
	thead td { border-left: 1px solid #808080; border-bottom: 1px solid #808080; border-top: 1px solid white; border-left: 1px solid white; border-right: 1px solid #808080; background-color: #D4D0C8; margin: 0px; padding: 1px; padding-left: 4px;}
	tbody td { padding-top: 2px; padding-bottom: 2px; padding-left: 4px; }
	.trEven { background-color: white; }
	.trOdd { background-color: #EEEEEE; }
	.statusred {color: #BB0000; }

</style>
</head>
<body onload="init();">
<form name="unzipForm" method="post" action="unzip.php">
<div class="mcBorderBottomWhite">
	<div class="mcHeader mcBorderBottomBlack">
		<div class="mcWrapper">
			<div class="mcHeaderLeft">
				<div class="mcHeaderTitle"><?= $this->lang['title']; ?></div>
				<div class="mcHeaderTitleText"><?= $this->lang['description']; ?></div>
			</div>
			<div class="mcHeaderRight">&nbsp;</div>
			<br style="clear: both" />
		</div>
	</div>
</div>
<div class="mcContent">
	<table border="0" cellspacing="0" cellpadding="4">
	  <tr>
		<td nowrap="nowrap"></td>
		<td></td>
	  </tr>
	</table>
	<? $i = 0; ?>
	<? foreach($this->data['out'] as $zipfile) { ?>
	<table border="0" cellspacing="0" cellpadding="4">
	  <tr>
		<td nowrap="nowrap"><strong><?= $this->lang['zipfile_name']; ?> </strong></td>
		<td><?= $zipfile['name']; ?></td>
	  </tr>
	  <tr>
		<td nowrap="nowrap"><strong><?= $this->lang['current_folder']; ?> </strong></td>
		<td><?= $this->data['short_path']; ?></td>
	  </tr>
	  <tr>
		<td nowrap="nowrap"><strong><?= $this->lang['overwrite_files']; ?> </strong></td>
		<td><input type="checkbox" disabled="disabled" name="overwrite_<?= $i; ?>" id="overwrite_<?= $i; ?>" value="yes" <?= (($zipfile['overwrite'] == "yes") ? "checked" : ""); ?> /></td>
	  </tr>
	</table>
	<table border="0" cellspacing="0" cellpadding="4" width="100%">
	  <tr>
		<td colspan="2">
			<table border="0" cellspacing="0" cellpadding="0" width="100%">
				<thead>
				<tr>
					<td>&nbsp;</td>
					<td><strong><?= $this->lang['name']; ?></strong></td>
					<td><strong><?= $this->lang['size']; ?></strong></td>
					<td><strong><?= $this->lang['csize']; ?></strong></td>
					<td><strong>&nbsp;</strong></td>
					<td><strong><?= $this->lang['exists']; ?></strong></td>
					<td><strong><?= $this->lang['status']; ?></strong></td>
					<td><strong><?= $this->lang['created']; ?></strong></td>
				</tr>
				</thead>
				<tbody>
		<? $even = true; ?>
		<? foreach($zipfile['contents'] as $item) { ?>
		<? $even = !$even; ?>
		<? if ($item['folder'] != 1) { ?>
				<tr class="<?= $even ? "trEven" : "trOdd"; ?>">
					<td align="center"><img src="themes/<?= $this->theme ?>/images/filetypes/<?=$item['icon']?>" width="16" height="16" alt="<?=$item['type']?>" title="<?=$item['type']?>" border="0" /></td>
					<td title="<?= $item['filename']; ?>"><?= $item['friendlypath']; ?></td>
					<td><?= $item['size']; ?></td>
					<td><?= $item['compressed_size']; ?></td>
					<td><?= $item['ratio'] ?>%</td>
					<td><?= $this->lang[$item['exists']] ?></td>
					<td title="<?= $item['status_message']; ?>" class="<?= ($item['status'] == "Failed") ? "statusred" : ""; ?>"><?= $this->lang[$item['status']]; ?></td>
					<td nowrap="nowrap"><?= $item['mtime']; ?></td>
				</tr>
		<? } else { ?>
				<tr class="<?= $even ? "trEven" : "trOdd"; ?>">
					<td align="center"><img src="themes/<?= $this->theme ?>/images/filetypes/folder.gif" width="16" height="16" alt="Directory" title="Directory" border="0" /></td>
					<td title="<?= $item['filename']; ?>"><?= $item['friendlypath']; ?></td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><?= $this->lang[$item['exists']] ?></td>
					<td title="<?= $item['status_message']; ?>" class="<?= ($item['status'] == "Failed") ? "statusred" : ""; ?>"><?= $this->lang[$item['status']]; ?></td>
					<td nowrap="nowrap"><?= $item['mtime']; ?></td>
				</tr>
		<? } ?>
		<? } ?>
				</tbody>
				</table>
		</td>
	  </tr>
	</table>
	<? if ($i != count($this->data['out'])-1) {?>
	<hr />
	<? } ?>
	<? $i++; ?>
	<? } ?>
</div>
<div class="mcFooter mcBorderTopBlack">
	<div class="mcBorderTopWhite">
		<div class="mcWrapper">
			<div class="mcFooterLeft"><input type="button" name="Back" value="<?= $this->lang['button_back']; ?>" class="button" onclick="history.go(-1);" /></div>
			<div class="mcFooterRight"><input type="button" name="Close" value="<?= $this->lang['button_close']; ?>" class="button" onclick="top.close();" /></div>
			<br style="clear: both" />
		</div>
	</div>
</div>
</form>
</body>
</html>


