<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?= $this->lang['title']; ?></title>
<link href="themes/<?= $this->theme ?>/css/general.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="themes/<?= $this->theme ?>/jscripts/general.js"></script>
</head>
<body id="previewBody">
<? if ($this->data['type'] == "dir") { ?>
<fieldset>
    <legend align="left"><?= $this->lang['directory_information']; ?></legend>
	<div style="margin: 2px; width: 100%; overflow: hidden;">
		<div class="previewSubTitle"><?= $this->lang['directory']; ?></div>
		<div class="previewText"><?=$this->data['filename']?></div>
	</div>
	<div style="float: left; margin: 2px; width: 45%;">
		<div class="previewSubTitle"><?= $this->lang['subdirectories']; ?></div>
		<div class="previewText"><?=$this->data['subdirs']?></div>
		<div class="previewSubTitle"><?= $this->lang['files']; ?></div>
		<div class="previewText"><?=$this->data['files']?></div>
		<div class="previewSubTitle"><?= $this->lang['total_file_size']; ?></div>
		<div class="previewText"><?=$this->data['filessize']?></div>
	</div>
	<div style="float: right; margin: 2px; width: 45%;">
		<div class="previewSubTitle"><?= $this->lang['creationdate']; ?></div>
		<div class="previewText"><?=$this->data['creationdate']?></div>
		<div class="previewSubTitle"><?= $this->lang['modificationdate']; ?></div>
		<div class="previewText"><?=$this->data['modificationdate']?></div>
		<div class="previewSubTitle"><?= $this->lang['access']; ?></div>
		<div class="previewText"><?=$this->lang[$this->data['readable']]?> / <?=$this->lang[$this->data['writable']]?></div>
	</div>
	<br style="clear: both" />
</fieldset>
<? } else if ($this->data['type'] == "file") { ?>
<fieldset>
    <legend align="left"><?= $this->lang['file_information']; ?></legend>
	<div style="float: left; margin: 2px; width: 45%; overflow: hidden;">
		<div class="previewSubTitle"><?= $this->lang['filename']; ?></div>
		<div class="previewText"><a href="stream.php?path=<?=$this->data['path']?>&mode=download" class="downloadLink"><?=$this->data['filename']?></a></div>
		<div class="previewSubTitle"><?= $this->lang['file_size']; ?></div>
		<div class="previewText"><?=$this->data['filesize']?></div>
		<div class="previewSubTitle"><?= $this->lang['file_description']; ?></div>
		<div class="previewText"><?=$this->lang[$this->data['description']]?></div>
	</div>

	<div style="float: right; margin: 2px; width: 45%;">
		<div class="previewSubTitle"><?= $this->lang['creationdate']; ?></div>
		<div class="previewText"><?=$this->data['creationdate']?></div>
		<div class="previewSubTitle"><?= $this->lang['modificationdate']; ?></div>
		<div class="previewText"><?=$this->data['modificationdate']?></div>
		<div class="previewSubTitle"><?= $this->lang['access']; ?></div>
		<div class="previewText"><?=$this->lang[$this->data['readable']]?> / <?=$this->lang[$this->data['writable']]?></div>
	</div>

	<br style="clear: both" />
</fieldset>

<fieldset class="previewFieldSet">
    <legend align="left"><?= $this->lang['preview']; ?></legend>
	<? if ($this->data['preview'] && $this->data['previewurl']) {?>
		<iframe id="previewIframe" name="previewIframe" unselectable="true" atomicselection="true" src="<?=$this->data['previewurl']?>" width="100%" height="200" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0" frameborder="0" border="0"></iframe>
	<? } else { ?>
		<div id="previewNoPreviewBox">
			<span id="previewNoPreviewText"><?= $this->lang['no_preview']; ?></span>
		</div>
	<? } ?>
</fieldset>

<br />

	<div style="float: left">
		<? if ($this->data['previewurl']) {?>
			<input type="button" id="view" name="view" value="<?= $this->lang['button_view']; ?>" onclick="window.open('<?=$this->data['previewurl']?>','previewWin');" class="button" />
		<? } else { ?>
			<input type="button" id="view" name="view" value="<?= $this->lang['button_view']; ?>" disabled="disabled" class="button" />
		<? } ?>
	</div>

	<div style="float: right">
		<? if ($this->data['previewurl']) {?>
			<input type="button" id="view" name="view" value="<?= $this->lang['button_select']; ?>" onclick="top.insertURL('<?=$this->data['previewurl']?>');" class="button" />
		<? } else { ?>
			<input type="button" id="insert" name="insert" value="<?= $this->lang['button_select']; ?>" disabled="disabled" class="button" />
		<? } ?>
	</div>

	<br style="clear: both" />
<? } ?>

</body>
</html>
