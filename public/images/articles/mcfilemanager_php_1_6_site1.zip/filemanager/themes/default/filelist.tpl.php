<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?= $this->lang['title']; ?></title>
<link href="themes/<?= $this->theme ?>/css/filelist.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
	var demo = <?= $this->data['demo'] ?>;
	var demoMsg = "<?= $this->data['demo_msg'] ?>";
	var disabledTools = '<?= $this->data['disabled_tools']?>';
	var hasReadAccess = <?= $this->data['hasReadAccess']?>;
	var hasWriteAccess = <?= $this->data['hasWriteAccess']?>;
	var hasPasteData = <?= $this->data['hasPasteData']?>;
	var path = "<?= $this->data['path']?>";
	var errorMsg = "<?= $this->data['errorMsg']?>";
	var imageManagerURLPrefix = "<?= $this->data['imageManagerURLPrefix']?>";
	var confirm_cut = "<?= $this->lang['confirm_cut']; ?>";
	var confirm_copy = "<?= $this->lang['confirm_copy']; ?>";
	var confirm_paste = "<?= $this->lang['confirm_paste']; ?>";
	var confirm_delete = "<?= $this->lang['confirm_delete']; ?>";
	var confirm_unzip = "<?= $this->lang['confirm_unzip']; ?>";
	var zip_removed = "<?= $this->lang['zip_removed']; ?>";
</script>
<script language="javascript" type="text/javascript" src="themes/<?= $this->theme ?>/jscripts/general.js"></script>
<script language="javascript" type="text/javascript" src="themes/<?= $this->theme ?>/jscripts/filelist.js"></script>
</head>
<body onload="init(errorMsg);">

<div id="toolbar">

<div class="toolbaritems">
<div style="float: left">
<nobr>
<?
	foreach ($this->data['tools'] as $item) {
		if (isset($item['location']) && $item['location'] == "right")
			continue;

		if ($item['command'] == "separator")
			echo '<img src="themes/' . $this->theme . '/images/spacer.gif" width="1" height="15" class="mceSeparatorLine" />';
		else
			echo '<a href="javascript:execFileCommand(\'' . $item['command'] . '\');"><img id="' . $item['command'] . '" src="themes/' . $this->theme . '/images/' . $item['icon'] . '" alt="' . $this->lang[$item['command']] . '" title="' . $this->lang[$item['command']] . '" border="0" class="mceButtonDisabled" width="20" height="20" /></a>';
	}
?>
</nobr>
</div>
<div style="float: right">
<nobr>
<?
	foreach ($this->data['tools'] as $item) {
		if (isset($item['location']) && $item['location'] == "left")
			continue;

		if ($item['command'] == "separator")
			echo '<img src="themes/' . $this->theme . '/images/spacer.gif" width="1" height="15" class="mceSeparatorLine" />';
		else
			echo '<a href="javascript:execFileCommand(\'' . $item['command'] . '\');"><img id="' . $item['command'] . '" src="themes/' . $this->theme . '/images/' . $item['icon'] . '" alt="' . $this->lang[$item['command']] . '" title="' . $this->lang[$item['command']] . '" border="0" class="mceButtonDisabled" width="20" height="20" /></a>';
	}
?>
</nobr>
</div>
<br style="clear: both" />
</div>

<div class="filelistPath" title="<?=$this->data['full_path']?>"><?=$this->data['short_path']?></div>
<table border="0" cellpadding="2" cellspacing="0" width="100%">
	<tr id="fileListHeadReal" class="filelistHeadRow">
		<td id="selectCol1" width="1" nowrap="nowrap" align="center" valign="middle"><a href="javascript:execFileCommand('toggleall');" title="<?= $this->lang['toggle_all'] ?>"><img id="toggleall" src="themes/<?= $this->theme ?>/images/box.gif" width="10" height="10" alt="<?= $this->lang['toggle_all'] ?>" border="0" hspace="3" /></a></td>
		<td id="iconCol1" width="20" nowrap="nowrap">&nbsp;</td>
		<td id="fnameCol1" width="100%" class="filelistHeadCol"><?= $this->lang['filename']; ?></td>
		<td id="fsizeCol1" width="1" nowrap="nowrap" class="filelistHeadCol"><?= $this->lang['size']; ?></td>
		<td id="fmodCol1" width="1%" nowrap="nowrap" class="filelistHeadCol"><?= $this->lang['modified']; ?></td>
		<td width="16" nowrap="nowrap" class="filelistHeadCol">&nbsp;</td>
	</tr>
</table></div>

<div id="filelist">
<form name="filelistForm" method="post" action="filelist.php">
	<table border="0" cellpadding="2" cellspacing="0" width="100%">
		<tr id="fileListHead" class="filelistHeadRow" style="height: 0px;">
			<td id="selectCol2" width="1" nowrap="nowrap" align="center" valign="middle">&nbsp;</td>
			<td id="iconCol2" width="1" nowrap="nowrap">&nbsp;</td>
			<td id="fnameCol2" width="100%" class="filelistHeadCol">&nbsp;</td>
			<td id="fsizeCol2" width="1" nowrap="nowrap" class="filelistHeadCol">&nbsp;</td>
			<td id="fmodCol2" width="1%" nowrap="nowrap" class="filelistHeadCol" colspan="2">&nbsp;</td>
		</tr>

		<tr height="0">
			<td width="1" nowrap="nowrap"></td>
			<td width="1" nowrap="nowrap"></td>
			<td width="100%" nowrap="nowrap"></td>
			<td width="1" nowrap="nowrap"></td>
			<td width="1%" nowrap="nowrap"></td>
			<td id="spacerCol" width="0"></td>
		</tr>

		<? $count = 0; ?>
		<? foreach ($this->data['files'] as $file) { ?>
		  <? if ($file['isParent']) { ?>
				<tr class="<?=($file['even'] ? "filelistRowEven" : "filelistRowOdd")?>">
					<td width="1"><input type="checkbox" name="dir_<?=($count++)?>" value="<?=$file['path']?>" disabled="disabled" /></td>
					<td><a href="filelist.php?path=<?=$file['path']?>&rootpath=<?=$this->data['rootpath']?>" onclick="showPreview('<?=$file['path']?>');"><img src="themes/<?= $this->theme ?>/images/filetypes/up_folder.gif" width="16" height="16" alt="<?=$this->lang['parent_dir']?>" " title="<?=$this->lang['parent_dir']?>" border="0" /></a></td>
					<td class="filelistFileName"><a href="filelist.php?path=<?=$file['path']?>&rootpath=<?=$this->data['rootpath']?>" onclick="showPreview('<?=$file['path']?>');"><?=$file['name']?></a></td>
					<td nowrap="nowrap">&nbsp;</td>
					<td nowrap="nowrap"><?=$file['modificationdate']?></td>
					<td id="spacerCol" width="0"></td>
				</tr>
		  <? } else if ($file['isDir']) { ?>
				<tr class="<?=($file['even'] ? "filelistRowEven" : "filelistRowOdd")?>">
					<td width="1"><input type="checkbox" name="dir_<?=($count++)?>" value="<?=$file['path']?>" onclick="triggerSelect(this);" <?if ($file['hasWriteAccess'] == "false") {?>disabled="disabled"<?}?> /></td>
					<td><?if ($file['hasReadAccess'] == "true") {?><a href="filelist.php?path=<?=$file['path']?>&rootpath=<?=$this->data['rootpath']?>" onclick="showPreview('<?=$file['path']?>');"><img src="themes/<?= $this->theme ?>/images/filetypes/folder.gif" width="16" height="16" alt="<?=$this->lang['dir']?>" title="<?=$this->lang['dir']?>" border="0" class="<?=($file['isCut'] ? "cutFile" : "")?>" /></a><?} else {?><img src="themes/default/images/filetypes/folder.gif" width="16" height="16" alt="Directory" title="Directory" border="0" class="<?=($file['isCut'] ? "cutFile" : "")?>" /><?}?></td>
					<td class="filelistFileName"><?if ($file['hasReadAccess'] == "true") {?><a href="filelist.php?path=<?=$file['path']?>&rootpath=<?=$this->data['rootpath']?>" onclick="showPreview('<?=$file['path']?>');"><?=$file['name']?></a><?} else {?><span class="disabledFileName"><?=$file['name']?></span><?}?></td>
					<td nowrap="nowrap">&nbsp;</td>
					<td nowrap="nowrap"><?=$file['modificationdate']?></td>
					<td id="spacerCol" width="0"></td>
				</tr>
		  <? } else { ?>
				<tr class="<?=($file['even'] ? "filelistRowEven" : "filelistRowOdd")?>">
					<td width="1"><input type="checkbox" name="file_<?=($count++)?>" value="<?=$file['path']?>" onclick="triggerSelect(this);" <?if ($file['hasWriteAccess'] == "false") {?>disabled="disabled"<?}?> /></td>
					<td><a name="<?=$file['name']?>"></a><a href="javascript:openFile('<?=$file['path']?>');" onclick="showPreview('<?=$file['path']?>');"><img src="themes/<?= $this->theme ?>/images/filetypes/<?=$file['icon']?>" width="16" height="16" alt="<?=$this->lang[$file['type']]?>" title="<?=$this->lang[$file['type']]?>" border="0" class="<?=($file['isCut'] ? "cutFile" : "")?>" /></a></td>
					<td class="filelistFileName"><?if ($file['hasReadAccess'] == "true") {?><a href="javascript:openFile('<?=$file['path']?>');" onclick="showPreview('<?=$file['path']?>');"><?=$file['name']?></a><?} else {?><span class="disabledFileName"><?=$file['name']?></span><?}?></td>
					<td nowrap="nowrap"><?=$file['size']?></td>
					<td nowrap="nowrap"><?=$file['modificationdate']?></td>
					<td id="spacerCol" width="0"></td>
				</tr>
		  <? } ?>
		<? } ?>
	</table>

	<input type="hidden" name="action" value="" />
	<input type="hidden" name="rootpath" value="<?=$this->data['rootpath']?>" />
	<input type="hidden" name="path" value="<?=$this->data['path']?>" />
</form>
</div>

</body>
</html>
