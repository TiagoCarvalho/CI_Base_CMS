Access in this directory is restricted by a mc_access file.
