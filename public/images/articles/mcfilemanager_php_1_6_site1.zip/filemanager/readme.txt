The MCFileManager PHP is a online file management utility that is seamlessly integrated with TinyMCE.
This utility can also be used standalone and it's easy to integrate with your backend system. MCFileManager
also integrates nicely with MCImageManager.

MCFileManager uses a third party ZIP library (PclZip) developed by PhpConcept http://www.phpconcept.net this library
is under LGPL and the compleate license and sourcecode for this library is included in the classes directory.

For more information about MCFileManager, MCImageManager or TinMCE visit the TinyMCE website http://tinymce.moxiecode.com/.
