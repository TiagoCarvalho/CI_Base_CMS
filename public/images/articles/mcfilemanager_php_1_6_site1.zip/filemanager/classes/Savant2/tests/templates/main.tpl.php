<?php
/**
* 
* Test includes and loadTemplate()
* 
* @version $Id: main.tpl.php,v 1.1 2004/10/04 01:52:24 pmjones Exp $
*
*/
?>

<?php include $this->loadTemplate('header.tpl.php') ?>

<?php include $this->loadTemplate('plugins.tpl.php') ?>

<?php include $this->loadTemplate('footer.tpl.php') ?>