<?php
/**
 * frameset.php
 *
 * @package MCFileManager.pages
 * @author Moxiecode
 * @copyright Copyright � 2005, Moxiecode Systems AB, All rights reserved.
 */

	// Use specified session instead
	if (isset($_REQUEST['sessionid']))
		session_id($_REQUEST['sessionid']);

	require_once("includes/general.php");
	require_once("classes/FileSystems/FileFactory.php");
	require_once("classes/FileSystems/LocalFileImpl.php");

	$data = array();

	verifyAccess($mcFileManagerConfig);
	$path = getRequestParam("path",toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.path')));
	$url = getRequestParam("url", "");
	$rootPath = getRequestParam("rootpath", toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.rootpath')));
	$fileFactory =& new FileFactory($mcFileManagerConfig, $rootPath);

	// Handle URL
	if ($url != "") {
		// Is absolute URL
		if (strpos($url, $mcFileManagerConfig['preview.urlprefix']) === 0) {
			// Trim away prefix
			$path = substr($url, strlen($mcFileManagerConfig['preview.urlprefix'])-1);

			// Add rest to wwwroot
			$path = toUnixPath(getWWWRoot($mcFileManagerConfig)) . $path;
		}

		// Try step 2
		if ($path == "") {
			$tmppath = toUnixPath(getWWWRoot($mcFileManagerConfig)) . $url;
			if ($fileFactory->verifyPath($tmppath)) {
				$file = $fileFactory->getFile($tmppath);

				if ($file->exists())
					$path = $file->getAbsolutePath();
			}
		}

		// Try step 2
		if ($path == "") {
			$tmppath = toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.rootpath')) . $url;
			if ($fileFactory->verifyPath($tmppath)) {
				$file = $fileFactory->getFile($tmppath);

				if ($file->exists())
					$path = $file->getAbsolutePath();
			}
		}
	}

	// No path defined, check session or root conf
	if (getRequestParam("remember", "") == "true") {
		if (isset($_SESSION['mc_filemanager_lastpath']))
			$path = $_SESSION['mc_filemanager_lastpath'];
		else
			$path = toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.path'));
	}

	// Invalid path, use root path
	if (!$fileFactory->verifyPath($path))
		$path = $rootPath;

	// Get file and config
	$targetFile =& $fileFactory->getFile($path);
	$config = $targetFile->getConfig();

	// Save away path
	$_SESSION['mc_filemanager_lastpath'] = $path;

	addFileEventListeners($fileFactory);

	$previewpath = $path;

	// Get parent dir if path points to a file
	$fileFactory =& new FileFactory($mcFileManagerConfig, $rootPath);
	$file =& $fileFactory->getFile($path);
	if ($file->exists()) {
		if ($file->isFile())
			$path = $file->getParent();

		$previewpath = $file->getAbsolutePath();
	} else {
		$path = toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.path'));
		$previewpath = toUnixPath(getRealPath($mcFileManagerConfig, 'filesystem.path'));
	}

	$data['path'] = $path;
	$data['previewpath'] = $previewpath;
	$data['previewfilename'] = basename($previewpath);
	$data['rootpath'] = $rootPath;
	$data['showpreview'] = checkBool($mcFileManagerConfig['preview']);
	$data['formname'] = getRequestParam("formname", "");
	$data['elementnames'] = getRequestParam("elementnames", "");
	$data['js'] = getRequestParam("js", "");

	// Render output
	renderPage("frameset.tpl.php", $data);
?>
